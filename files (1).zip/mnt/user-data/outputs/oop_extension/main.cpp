#include "Person.h"
#include "StaffMember.h"
#include "DormSupervisor.h"
#include "RestaurantStaff.h"
#include "StaffRegistry.h"

#include <iostream>
#include <memory>

// ============================================================
// Standalone console demo.
//
// Purpose: prove that Inheritance + Polymorphism work correctly
// in this NEW subsystem, completely independent from the
// existing Qt project (Student/Room/Dormitory/University are
// untouched and not included here).
//
// What this demonstrates:
//   1. Person is abstract -> cannot be instantiated directly.
//   2. DormSupervisor and RestaurantStaff both inherit
//      StaffMember -> StaffMember inherits Person (2-level
//      inheritance chain).
//   3. Both override getRole()/describe() differently
//      (function overriding).
//   4. StaffRegistry stores them as Person* (via unique_ptr) and
//      calls describe()/getRole() WITHOUT knowing the concrete
//      type -> true runtime polymorphism, not just shared code.
// ============================================================

int main()
{
    std::cout << "===== STAFF POLYMORPHISM DEMO =====\n\n";

    StaffRegistry registry;

    // Add a DormSupervisor and a RestaurantStaff — both stored
    // as Person* underneath, through unique_ptr ownership.
    registry.addStaffMember(
        std::make_unique<DormSupervisor>(101, "Karim Belaid", 65000.0, "Ibn Sina Residence"));

    registry.addStaffMember(
        std::make_unique<RestaurantStaff>(102, "Amel Cherif", 48000.0, "Morning"));

    registry.addStaffMember(
        std::make_unique<DormSupervisor>(103, "Yacine Touati", 65000.0, "El Khawarizmi Residence"));

    registry.addStaffMember(
        std::make_unique<RestaurantStaff>(104, "Nadia Boumediene", 48000.0, "Evening"));

    std::cout << "Total staff registered: " << registry.getStaffCount() << "\n\n";

    std::cout << "--- Polymorphic display (same loop, different behavior) ---\n";
    registry.displayAllStaff();
    std::cout << "\n";

    std::cout << "--- Role-based counting via getRole() ---\n";
    std::cout << "Dorm Supervisors:  " << registry.countByRole("Dorm Supervisor")  << "\n";
    std::cout << "Restaurant Staff:  " << registry.countByRole("Restaurant Staff") << "\n\n";

    // Direct demonstration: a base-class pointer calling an
    // overridden virtual function resolves at runtime.
    std::cout << "--- Direct Person* polymorphism check ---\n";
    std::unique_ptr<Person> someone =
        std::make_unique<DormSupervisor>(105, "Sara Amari", 70000.0, "El Khawarizmi Residence");
    std::cout << "Static type: Person*  |  Runtime role: " << someone->getRole() << "\n";
    std::cout << someone->describe() << "\n\n";

    // Removing by id, demonstrated through the registry
    registry.removeStaffMember(102);
    std::cout << "After removing staff ID 102, total staff: "
              << registry.getStaffCount() << "\n";

    // The following line would NOT compile if uncommented,
    // because Person is abstract (pure virtual getRole/describe):
    // Person p(999, "Invalid");  // ERROR: cannot instantiate abstract class

    return 0;
}
